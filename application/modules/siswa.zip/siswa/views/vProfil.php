<div class="row">
	<div class="col-sm-12">
		<div class="iq-card iq-card-block iq-card-stretch iq-card-height ">
			<div class="iq-card-body relative-background">
				<div class="row">
					<div class="col-md-12">
						<?php $this->load->view($page); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>